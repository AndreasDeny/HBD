## Happy Birthday!!!

### Wish someone special happy birthday in a special way.

#### [Demo](https://fajaraldev.github.io/template-happybirthday/)

It was a birthday of one of my friend and I wanted to wish her in a special way. So I put together this animated web page real quick to say Happy Birthday.

Feel free to use it to wish your friend if you want.
You can get it running in a few easy steps:

- Fork the repository
- Open `customize.json` and replace name/wish-message/image with your own
- Turn on GitHub pages for the repository (Settings > GitHub Pages)
- Send the URL that you get at the above step to your friend

I've created the JSON file for easy and quick customizability. If you want to do more customizing, simply edit the HTML file. But in that case, leave the JSON fields empty since it overwrites the HTML. Please note that I've created this page in a hurry and it comes with no warranty, so check yourself before sending it to your friend.

I've used plain HTML, CSS and JavaScript with [GSAP](https://greensock.com/gsap) for animations.

## Contributing

If you have any idea to make it more interesting, feel free to send a PR, or create an issue for a feature request.

Stay happy and keep the people you care about happy. :)
